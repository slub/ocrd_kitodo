#!/bin/sh

TASK=$(basename $0)
PROCESS_ID=$1
TASK_ID=$2

if test -z "$PROCESS_ID"; then
  logger -p user.error -t $TASK "process ID not found"
  exit 2
fi

if test -z "$TASK_ID"; then
  logger -p user.error -t $TASK "task ID not found"
  exit 3
fi

logger -p user.notice -t $TASK "running for_production.sh $PROCESS_ID $TASK_ID /data/$PROCESS_ID deu Fraktur"

ssh -i /.ssh/id_rsa -Tn -p 22 ocrd@ocrd-manager for_production.sh $PROCESS_ID $TASK_ID /data/$PROCESS_ID deu Fraktur
