#!/bin/sh

TASK=$(basename $0)
PROCESS_ID=$1
TASK_ID=$2

if test -z "$PROCESS_ID"; then
  logger -p user.error -t $TASK "process ID not found"
  exit 2
fi

if test -z "$TASK_ID"; then
  logger -p user.error -t $TASK "task ID not found"
  exit 3
fi

logger -p user.notice -t $TASK "ssh host '$OCRD_MANAGER_HOST' port '$OCRD_MANAGER_PORT' running script for_production.sh $PROCESS_ID $TASK_ID /data/$PROCESS_ID deu Fraktur"

ssh -i /.ssh/id_rsa -Tn -p $OCRD_MANAGER_PORT ocrd@$OCRD_MANAGER_HOST for_production.sh $PROCESS_ID $TASK_ID /data/$PROCESS_ID deu Fraktur
