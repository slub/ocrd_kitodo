#!/bin/sh

PROCESSID=$1
TASKID=$2

ssh -i /.ssh/id_rsa -Tn -p 22 ocrd@ocrd-manager for_production.sh $PROCESSID $TASKID /data/$PROCESSID deu Fraktur ocr.sh

exit 1

