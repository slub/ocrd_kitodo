#!/bin/sh

TASK=$(basename $0)
PROCESSID=$1
TASKID=$2

if test -z "$PROCESSID"; then
	logger -p user.error -t $TASK "process ID not found"
	exit 2
fi

if test -z "$TASKID"; then
	logger -p user.error -t $TASK "task ID not found"
	exit 3
fi

logger -p user.notice -t $TASK "running for_production.sh $PROCESSID $TASKID /data/$PROCESSID deu Fraktur ocr.sh"

ssh -i /.ssh/id_rsa -Tn -p 22 ocrd@ocrd-manager for_production.sh $PROCESSID $TASKID /data/$PROCESSID deu Fraktur ocr.sh